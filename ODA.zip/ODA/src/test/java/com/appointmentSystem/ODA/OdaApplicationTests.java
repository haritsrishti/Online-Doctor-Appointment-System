package com.appointmentSystem.ODA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OdaApplicationTests {

	@Test
	void contextLoads() {
	}

}
